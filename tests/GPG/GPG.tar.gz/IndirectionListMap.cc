#include "IndirectionListMap.h"

bool IndirectionListMap::has(const IndirectionList *list) const {
    return map_.find(list) != map_.end();
}

IndirectionList *IndirectionListMap::find(IndirectionList *list) {
    auto it = map_.find(list);

    if (it == map_.end())
        return nullptr;

    return *it;
}


IndirectionList *findOrInsert(IndirectionList *list) {
    auto l = find(list);

    if (l == nullptr) {
        map_.insert(list);
        return list;
    }

    return l;
}
